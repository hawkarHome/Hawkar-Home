import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hawkar Home | Furniture & Design",
  description: "Premium furniture website for Hawkar Home in Sulaymaniyah, Iraq."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="ku" dir="rtl"><body>{children}</body></html>;
}
