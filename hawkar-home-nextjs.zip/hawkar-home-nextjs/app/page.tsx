import Image from "next/image";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PriceCalculator from "@/components/PriceCalculator";
import { categories, products } from "@/data/products";

const categoryIcons = ["🛋️", "🛏️", "📺", "👞", "🚪", "📚", "🍽️", "🪞", "👔"];
const gallery = [
  "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?q=80&w=1100&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1618220179428-22790b461013?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1617806118233-18e1de247200?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1615873968403-89e068629265?q=80&w=900&auto=format&fit=crop"
];

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <section className="hero" id="home">
          <div className="hero-content">
            <Image className="hero-logo" src="/logo.png" alt="Hawkar Home" width={170} height={170} />
            <div className="badge">Where Living Meets Design</div>
            <h1>مۆبڵیای لوکس بۆ ماڵێکی مۆدێرن</h1>
            <p>لە Hawkar Home، دیزاین، کوالێتی و ڕەنگی سروشتی پێکەوە دەهێنین بۆ ئەوەی ماڵەکەت جوانتر و گەرمتر بێت.</p>
            <a className="btn" href="#products">بینینی بەرهەمەکان</a>{" "}
            <a className="btn light" href="#contact">پەیوەندی بکە</a>
          </div>
        </section>

        <section id="categories">
          <div className="container">
            <div className="section-title"><h2>بەشەکانی مۆبڵیا</h2><p>هەموو بەرهەمەکان دەتوانرێت بە قەبارە، ڕەنگ، ماددە و مۆدێلی داواکراوی کڕیار دروست بکرێن.</p></div>
            <div className="grid">{categories.map((category, index) => <div className="card category-card" key={category}><span>{categoryIcons[index]}</span><h3>{category}</h3><p>Custom design & premium finishing</p></div>)}</div>
          </div>
        </section>

        <section className="products" id="products">
          <div className="container">
            <div className="section-title"><h2>بەرهەمە پێشنیارکراوەکان</h2><p>ئەم نرخانە نموونەیین، تۆ دەتوانیت دواتر بە نرخە ڕاستەقینەکانی خۆت بیگۆڕیت.</p></div>
            <div className="product-grid">{products.map((product) => <article className="card product" key={product.id}><Image src={product.image} alt={product.nameKu} width={900} height={600} /><div className="info"><h3>{product.nameKu}</h3><p>{product.nameEn}</p><div className="price">لە ${product.basePrice} دەست پێ دەکات</div></div></article>)}</div>
          </div>
        </section>

        <PriceCalculator />

        <section id="gallery">
          <div className="container">
            <div className="section-title"><h2>گالەری دیزاین</h2><p>وێنە نموونەییەکان دواتر بە وێنەی بەرهەمە ڕاستەقینەکانی Hawkar Home دەگۆڕدرێن.</p></div>
            <div className="gallery-grid">{gallery.map((img, index) => <Image src={img} alt={`Gallery ${index + 1}`} width={1100} height={750} key={img} />)}</div>
          </div>
        </section>

        <section><div className="container features"><div className="feature"><div className="icon">🎨</div><h3>دیزاینی تایبەت</h3><p>بە پێی قەبارە و ستایلی ماڵەکەت دیزاین دەکرێت.</p></div><div className="feature"><div className="icon">🧮</div><h3>نرخی خۆکار</h3><p>کڕیار هەڵدەبژێرێت و سیستەم کۆی گشتی دەهێنێتەوە.</p></div><div className="feature"><div className="icon">🚚</div><h3>گواستنەوە</h3><p>گواستنەوە و گەیاندن بۆ سلێمانی و شوێنەکانی تر.</p></div></div></section>

        <section className="contact" id="contact">
          <div className="container contact-grid">
            <div><h2 style={{ fontSize: 44, marginBottom: 16 }}>پەیوەندی بە Hawkar Home بکە</h2><p>بۆ داواکاری، پێوانەکردن، دیزاین و نرخ، ڕاستەوخۆ پەیوەندی بکە.</p></div>
            <div className="contact-card"><p><strong>📍 ناونیشان:</strong> سلێمانی - گوڵی شار</p><p><strong>📞 مۆبایل:</strong> 07700822009</p><p><strong>📧 ئیمەیڵ:</strong> HawkarHome2011@gmail.com</p><div className="socials"><a href="https://facebook.com/hawkar.home" target="_blank">Facebook</a><a href="https://instagram.com/hawkar.home" target="_blank">Instagram</a><a href="https://tiktok.com/@hawkar.home" target="_blank">TikTok</a><a href="https://youtube.com/@hawkar.home" target="_blank">YouTube</a></div></div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
