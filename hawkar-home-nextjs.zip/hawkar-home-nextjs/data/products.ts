export const products = [
  { id: "sofa", nameKu: "کەوانتەر مۆدێرن", nameEn: "Modern Sofa", category: "کەوانتەر", basePrice: 850, image: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=1200&auto=format&fit=crop" },
  { id: "bedroom", nameKu: "ژووری نوستن لوکس", nameEn: "Luxury Bedroom", category: "ژووری نوستن", basePrice: 1450, image: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?q=80&w=1200&auto=format&fit=crop" },
  { id: "tv", nameKu: "مێزی تەلەفزیۆن", nameEn: "TV Unit", category: "مێزی TV", basePrice: 350, image: "https://images.unsplash.com/photo-1615873968403-89e068629265?q=80&w=1200&auto=format&fit=crop" },
  { id: "partition", nameKu: "پارتیشن", nameEn: "Partition", category: "پارتیشن", basePrice: 420, image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?q=80&w=1200&auto=format&fit=crop" },
  { id: "bookshelf", nameKu: "کتێبخانە", nameEn: "Bookshelf", category: "کتێبخانە", basePrice: 480, image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=1200&auto=format&fit=crop" },
  { id: "dining", nameKu: "مێزی نانخواردن", nameEn: "Dining Table", category: "مێزی نانخواردن", basePrice: 700, image: "https://images.unsplash.com/photo-1617806118233-18e1de247200?q=80&w=1200&auto=format&fit=crop" },
  { id: "console", nameKu: "کونسوڵ", nameEn: "Console Table", category: "کونسوڵ", basePrice: 300, image: "https://images.unsplash.com/photo-1567016376408-0226e4d0c1ea?q=80&w=1200&auto=format&fit=crop" },
  { id: "shoe", nameKu: "شوێنی پێڵاو", nameEn: "Shoe Cabinet", category: "شوێنی پێڵاو", basePrice: 250, image: "https://images.unsplash.com/photo-1618220179428-22790b461013?q=80&w=1200&auto=format&fit=crop" },
  { id: "wardrobe", nameKu: "جلپۆش", nameEn: "Wardrobe", category: "جلپۆش", basePrice: 950, image: "https://images.unsplash.com/photo-1595428774223-ef52624120d2?q=80&w=1200&auto=format&fit=crop" }
];

export const categories = ["کەوانتەر", "ژووری نوستن", "مێزی TV", "شوێنی پێڵاو", "پارتیشن", "کتێبخانە", "مێزی نانخواردن", "کونسوڵ", "جلپۆش"];
