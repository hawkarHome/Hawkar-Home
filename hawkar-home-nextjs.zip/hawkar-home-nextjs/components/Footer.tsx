export default function Footer() {
  return (
    <>
      <a className="whatsapp" href="https://wa.me/9647700822009" target="_blank" aria-label="WhatsApp">☎</a>
      <footer>© 2026 Hawkar Home — Where Living Meets Design</footer>
    </>
  );
}
