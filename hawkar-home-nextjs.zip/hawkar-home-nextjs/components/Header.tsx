import Image from "next/image";

export default function Header() {
  return (
    <header className="header">
      <div className="container nav">
        <a className="brand" href="#home">
          <Image className="logo" src="/logo.png" alt="Hawkar Home logo" width={58} height={58} />
          <span>Hawkar Home</span>
        </a>
        <nav className="menu">
          <a href="#home">سەرەکی</a>
          <a href="#categories">بەشەکان</a>
          <a href="#products">بەرهەمەکان</a>
          <a href="#calculator">هەژمارکردنی نرخ</a>
          <a href="#gallery">گالەری</a>
          <a href="#contact">پەیوەندی</a>
        </nav>
        <a className="btn secondary" href="#calculator">نرخ هەژمار بکە</a>
      </div>
    </header>
  );
}
