 "use client";

import { useMemo, useState } from "react";
import { products } from "@/data/products";

const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

export default function PriceCalculator() {
  const [item, setItem] = useState(products[0].id);
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState(1);
  const [material, setMaterial] = useState(1);
  const [color, setColor] = useState(0);
  const [accessory, setAccessory] = useState(0);
  const [delivery, setDelivery] = useState(0);
  const [deposit, setDeposit] = useState(0.2);

  const selected = products.find((p) => p.id === item) || products[0];

  const calc = useMemo(() => {
    const base = selected.basePrice * qty;
    const custom = base * size * material;
    const extras = (color + accessory) * qty + delivery;
    const total = custom + extras;
    return { base, custom, extras, total, depositValue: total * deposit };
  }, [selected, qty, size, material, color, accessory, delivery, deposit]);

  function sendWhatsApp() {
    const message = [
      "سڵاو Hawkar Home",
      "داواکاری نرخ:",
      `بەرهەم: ${selected.nameKu}`,
      `ژمارە: ${qty}`,
      `کۆی گشتی: ${money.format(calc.total)}`,
      `پێشەکی: ${money.format(calc.depositValue)}`,
      "تکایە پەیوەندیم پێوە بکەن."
    ].join("%0A");
    window.open(`https://wa.me/9647700822009?text=${message}`, "_blank");
  }

  return (
    <section className="calculator" id="calculator">
      <div className="container">
        <div className="section-title">
          <h2>هەژمارکردنی نرخ</h2>
          <p>کڕیار جۆری بەرهەم، قەبارە، ماددە، ڕەنگ و ژمارە دیاری دەکات و کۆی گشتی خۆکار دەردەکەوێت.</p>
        </div>
        <div className="calc-box">
          <div className="panel">
            <div className="row">
              <div><label>جۆری بەرهەم</label><select value={item} onChange={(e) => setItem(e.target.value)}>{products.map((p) => <option key={p.id} value={p.id}>{p.nameKu} — ${p.basePrice}</option>)}</select></div>
              <div><label>ژمارە</label><input type="number" min={1} value={qty} onChange={(e) => setQty(Math.max(1, Number(e.target.value)))} /></div>
            </div>
            <div className="row">
              <div><label>قەبارە</label><select value={size} onChange={(e) => setSize(Number(e.target.value))}><option value={1}>ستاندارد</option><option value={1.25}>گەورە</option><option value={1.5}>VIP / گەورەتر</option></select></div>
              <div><label>ماددە</label><select value={material} onChange={(e) => setMaterial(Number(e.target.value))}><option value={1}>MDF</option><option value={1.25}>دار + MDF</option><option value={1.55}>دارى کوالێتی بەرز</option></select></div>
            </div>
            <div className="row">
              <div><label>ڕەنگ</label><select value={color} onChange={(e) => setColor(Number(e.target.value))}><option value={0}>Olive Green</option><option value={0}>Espresso Brown</option><option value={0}>Sand Beige</option><option value={0}>Warm Cream</option><option value={25}>ڕەنگی تایبەت + $25</option></select></div>
              <div><label>Accessory</label><select value={accessory} onChange={(e) => setAccessory(Number(e.target.value))}><option value={0}>بێ زیادە</option><option value={75}>LED + $75</option><option value={120}>Soft Close + $120</option><option value={200}>Premium Handles + $200</option></select></div>
            </div>
            <div className="row">
              <div><label>پێشەکی</label><select value={deposit} onChange={(e) => setDeposit(Number(e.target.value))}><option value={0.1}>10%</option><option value={0.2}>20%</option><option value={0.3}>30%</option><option value={0.5}>50%</option></select></div>
              <div><label>گواستنەوە</label><select value={delivery} onChange={(e) => setDelivery(Number(e.target.value))}><option value={0}>لە فرۆشگا وەرگرتن</option><option value={25}>ناو سلێمانی + $25</option><option value={60}>دەرەوەی سلێمانی + $60</option></select></div>
            </div>
          </div>
          <div className="panel">
            <h3 style={{ fontSize: 28, marginBottom: 14 }}>کورتەی نرخ</h3>
            <div className="summary-line"><span>نرخی بنەڕەتی</span><strong>{money.format(calc.base)}</strong></div>
            <div className="summary-line"><span>دوای قەبارە و ماددە</span><strong>{money.format(calc.custom)}</strong></div>
            <div className="summary-line"><span>زیادەکان و گواستنەوە</span><strong>{money.format(calc.extras)}</strong></div>
            <div className="summary-line"><span>کۆی گشتی</span><strong className="total">{money.format(calc.total)}</strong></div>
            <div className="summary-line"><span>پێشەکی</span><strong>{money.format(calc.depositValue)}</strong></div>
            <button className="btn" style={{ width: "100%", marginTop: 22 }} onClick={sendWhatsApp}>ناردنی داواکاری بە WhatsApp</button>
            <div className="payment-box"><strong>پارەدانی ئۆنلاین:</strong><p>SuperQi و FIB Iraq لە وەشانی داهاتوودا بە Merchant Account ـەکەت دەبەسترێت.</p></div>
          </div>
        </div>
      </div>
    </section>
  );
}
